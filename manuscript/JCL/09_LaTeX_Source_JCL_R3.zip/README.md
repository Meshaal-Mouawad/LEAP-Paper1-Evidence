# LEAP Paper 1 — JCL R3 editable source

Compile `main.tex` with `pdflatex` twice in a standard LaTeX environment with the packages named in the preamble. The included `cas-dc.cls` and `cas-common.sty` accompany the manuscript.

The four vector PDFs in `figs/` are the approved manuscript inputs. Their SVG counterparts retain editable text. Figure captions and the original drawing source are supplied. To regenerate figures, run `python3 build_figures.py` with Matplotlib and the Liberation Sans, DejaVu Sans Mono and STIX fonts installed. The included PDFs support compilation independently of regeneration.

R3 adds one methodological comparison table and clarifies the second-stage measurement endpoint. The four figure artworks and captions, original numerical results, equations, listings, research questions, abstract and bibliography are unchanged from R2.

This journal-facing archive contains build sources and figure production materials. Editorial reviews, source-evidence maps and design records are supplied separately in the outer package's `Editorial_Record/` directory.
