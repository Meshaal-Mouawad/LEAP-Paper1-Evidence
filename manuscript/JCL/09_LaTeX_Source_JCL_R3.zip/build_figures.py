"""LEAP scientific figures: exact, editable vector drawing, 2026-11-05.

Run: python3 build_figures.py. Requires matplotlib. No external services.
All figure coordinates are in points; output width is 540 pt.
"""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon, FancyArrowPatch, PathPatch
from matplotlib.path import Path as MPath
from matplotlib import font_manager as fm

OUT = Path(__file__).resolve().parent / 'figs'
OUT.mkdir(exist_ok=True)
SANS='Liberation Sans'
plt.rcParams.update({'font.family':SANS,'font.size':9,'pdf.fonttype':42,
                     'ps.fonttype':42,'svg.fonttype':'none','mathtext.fontset':'stix',
                     'axes.unicode_minus':False})
NAVY='#18354B'; TEAL='#227C83'; AMBER='#A5641B'; INK='#1C2C36'; GRAY='#5B6972'
LINE='#B8C5CC'; BLUE_FILL='#EDF3F7'; TEAL_FILL='#EDF6F5'; AMBER_FILL='#FCF3E6'
WHITE='#FFFFFF'

def canvas(h):
    fig=plt.figure(figsize=(540/72,h/72),facecolor=WHITE)
    ax=fig.add_axes([0,0,1,1]); ax.set(xlim=(0,540),ylim=(h,0)); ax.axis('off')
    return fig,ax

def txt(ax,x,y,s,size=9,color=INK,weight='normal',ha='left',va='top',mono=False):
    return ax.text(x,y,s,fontsize=size,color=color,fontweight=weight,ha=ha,va=va,
                   fontfamily='DejaVu Sans Mono' if mono else SANS,linespacing=1.32)

def box(ax,x,y,w,h,fill=WHITE,edge=LINE,lw=.8):
    p=Rectangle((x,y),w,h,facecolor=fill,edgecolor=edge,linewidth=lw); ax.add_patch(p); return p

def line(ax,x1,y1,x2,y2,c=LINE,lw=.8,dash=False):
    ax.plot([x1,x2],[y1,y2],color=c,lw=lw,ls=(0,(3,2)) if dash else '-',solid_capstyle='butt')

def arrow(ax,pts,c=NAVY,lw=1):
    if len(pts)>2:
        path=MPath(pts,[MPath.MOVETO]+[MPath.LINETO]*(len(pts)-1))
        p=FancyArrowPatch(path=path,arrowstyle='-|>',mutation_scale=7,lw=lw,color=c,joinstyle='miter')
    else: p=FancyArrowPatch(pts[0],pts[1],arrowstyle='-|>',mutation_scale=7,lw=lw,color=c,shrinkA=0,shrinkB=0)
    ax.add_patch(p)

def heading(ax,x,y,letter,title):
    txt(ax,x,y,letter,10.5,NAVY,'bold'); txt(ax,x+18,y,title,10.5,NAVY,'bold')

def node(ax,x,y,w,h,title,body='',fill=WHITE):
    box(ax,x,y,w,h,fill,NAVY,.9)
    txt(ax,x+8,y+8,title,9.4,NAVY,'bold')
    if body: txt(ax,x+8,y+24,body,8.4,GRAY)

def paper(ax,x,y,w,h,title,color=NAVY,fill=WHITE):
    path=[(x,y),(x+w-10,y),(x+w,y+10),(x+w,y+h),(x,y+h)]
    ax.add_patch(Polygon(path,closed=True,facecolor=fill,edgecolor=color,lw=.9))
    line(ax,x+w-10,y,x+w-10,y+10,color); line(ax,x+w-10,y+10,x+w,y+10,color)
    txt(ax,x+9,y+10,title,9.4,color,'bold')

def save(fig,name):
    for ext in ['pdf','svg']:
        fig.savefig(OUT/f'{name}.{ext}',facecolor=WHITE,metadata={'Creator':'LEAP figure source'})
    fig.savefig(OUT/f'{name}.png',dpi=200,facecolor=WHITE)
    plt.close(fig)

def architecture():
    fig,ax=canvas(310)
    heading(ax,8,7,'A','Original reconstruction and publication path')
    paper(ax,8,36,95,79,'Source snapshot',fill=BLUE_FILL)
    txt(ax,17,62,'Code + declarations\nLocal metadata\nPath + source span',8.5)
    arrow(ax,[(103,75),(124,75)])
    node(ax,124,36,119,79,'Candidate extraction','Name + source anchor\nCandidate-local evidence\nPromotion rules',BLUE_FILL)
    arrow(ax,[(243,75),(273,75)])
    # Decision 1, diagonal geometry reserved exclusively for branching.
    ax.add_patch(Polygon([(305,43),(339,75),(305,107),(271,75)],closed=True,facecolor=WHITE,edgecolor=NAVY,lw=1))
    txt(ax,305,75,'Promote?',9,NAVY,'bold','center','center')
    txt(ax,305,28,'DECISION 1',7.8,GRAY,'bold',ha='center')
    arrow(ax,[(339,75),(375,75)]); txt(ax,350,61,'Yes',8,GRAY)
    node(ax,375,36,157,79,'Page preparation','Declared / executable formulas\nBusiness fields + origins\nReview signals',BLUE_FILL)
    arrow(ax,[(305,107),(305,148)])
    txt(ax,314,122,'No',8,GRAY)
    node(ax,238,148,134,50,'Extraction Review','Candidate + routing reason',AMBER_FILL)
    arrow(ax,[(454,115),(454,157)])
    txt(ax,463,128,'DECISION 2',7.8,GRAY,'bold')
    node(ax,391,157,141,55,'Assign page status','Needs Review / Validated',TEAL_FILL)
    txt(ax,398,195,'System state',7.8,GRAY)
    arrow(ax,[(454,212),(454,241)])
    paper(ax,391,241,141,57,'Interactive Bluebook',TEAL,TEAL_FILL)
    txt(ax,400,264,'Developer / business / reviewer\nviews of one linked record',8.3)
    # Record structure explains the shared evidence object without another workflow.
    heading(ax,8,149,'B','Fields retained in the KPI record')
    box(ax,8,174,213,124,WHITE,NAVY,.9)
    fields=[('Identity','path / anchor / name'),('Source evidence','region + content hash'),
            ('Formula origins','declared / executable'),('Business context','value + origin'),('Review information','signals + recorded decisions')]
    for i,(k,v) in enumerate(fields):
        y=180+i*23
        if i: line(ax,8,y-5,221,y-5)
        txt(ax,16,y,k,8.5,NAVY,'bold'); txt(ax,16,y+10,v,8.1,GRAY)
    txt(ax,238,239,'Promotion selects a path.\nPage preparation assigns\nthe displayed status.',9,INK)
    save(fig,'fig01_reconstruction')

def channels():
    fig,ax=canvas(242)
    txt(ax,8,7,'Two origins in the Gross Margin example',10.5,NAVY,'bold')
    txt(ax,8,26,'Curated demonstration',8.2,GRAY)
    paper(ax,8,48,229,90,'Declared formula',NAVY,BLUE_FILL)
    txt(ax,19,72,'Origin: candidate-local declaration',8.5,GRAY)
    txt(ax,122.5,105,r'$\dfrac{\mathrm{Revenue}-\mathrm{Cost}}{\mathrm{Revenue}}\times100$',17,NAVY,ha='center',va='center')
    paper(ax,303,48,229,90,'Recovered executable expression',TEAL,TEAL_FILL)
    txt(ax,314,72,'Origin: selected source calculation',8.5,GRAY)
    txt(ax,417.5,105,r'$\dfrac{\mathrm{Revenue}}{\mathrm{Cost}}\times100$',17,TEAL,ha='center',va='center')
    txt(ax,270,103,r'$\ne$',22,AMBER,ha='center',va='center')
    arrow(ax,[(122,138),(122,166),(196,166)],NAVY)
    arrow(ax,[(418,138),(418,166),(344,166)],TEAL)
    box(ax,196,152,148,28,AMBER_FILL,AMBER,.9)
    txt(ax,270,166,'Conflict retained',10,AMBER,'bold','center','center')
    arrow(ax,[(270,180),(270,194)],AMBER)
    box(ax,8,194,524,40,WHITE,NAVY,.9)
    txt(ax,18,201,'ONE SOURCE-BOUND RECORD',8,NAVY,'bold')
    txt(ax,18,216,'conflict_formula_margin.py',8.4,INK,mono=True)
    txt(ax,217,201,'KPIREC-76E8A3DB97FA003A',8.1,INK,mono=True)
    txt(ax,217,216,'Both formula origins remain visible',8.5,GRAY)
    box(ax,416,201,105,25,AMBER_FILL,AMBER,.7)
    txt(ax,468.5,213.5,'Needs Review',9.5,AMBER,'bold','center','center')
    save(fig,'fig02_formula_origins')

def geometry():
    fig,ax=canvas(288)
    heading(ax,8,7,'A','One function, two source locations')
    txt(ax,8,27,'R10: financialHealthToolkit/CompaniesMod.py',8.8,GRAY)
    # Source is verbatim, with the surrounding method indentation normalized.
    box(ax,8,48,350,111,WHITE,NAVY,.9)
    code=['def current_ratio(self):','    try:','        return self.current_assets / self.current_lia','    except ZeroDivisionError:','        return 0']
    ys=[60,79,98,117,136]
    box(ax,9,54,348,18,BLUE_FILL,BLUE_FILL,0)
    box(ax,9,92,348,18,TEAL_FILL,TEAL_FILL,0)
    for i,(s,y) in enumerate(zip(code,ys)):
        txt(ax,18,y,str(78+i),8.7,GRAY,mono=True)
        txt(ax,40,y,s,8.35,INK,mono=True)
    arrow(ax,[(358,63),(382,63)],NAVY)
    txt(ax,389,53,'Baseline anchor: 78',9,NAVY,'bold')
    txt(ax,389,68,'Function definition',8.5,GRAY)
    arrow(ax,[(358,101),(382,101)],TEAL)
    txt(ax,389,92,'Reference span: [80, 80]',9,TEAL,'bold')
    txt(ax,389,107,'Returned calculation',8.5,GRAY)
    heading(ax,8,178,'B','Frozen coordinate test')
    line(ax,38,222,258,222,GRAY,1)
    for number,x in zip(range(78,83),[48,98,148,198,248]):
        line(ax,x,218,x,226,GRAY,.8)
        txt(ax,x,235,str(number),8.5,GRAY,ha='center')
    ax.plot([48],[222],marker='o',color=NAVY,markersize=5)
    box(ax,141,216,14,12,TEAL_FILL,TEAL,1.3)
    txt(ax,48,199,'Prediction',8.5,NAVY,ha='center')
    txt(ax,148,199,'Reference',8.5,TEAL,ha='center')
    txt(ax,148,253,'Source line',8.2,GRAY,ha='center')
    txt(ax,318,207,r'$78\notin[80,80]$',17,AMBER)
    txt(ax,318,238,'No primary match',10,AMBER,'bold')
    txt(ax,8,274,'The function contains the reference return; its anchor falls outside the reference span.',9,INK)
    save(fig,'fig03_occurrence_matching')

def mechanisms():
    fig,ax=canvas(471)
    # A: show the actual lost token, not an icon of a generic broken algorithm.
    heading(ax,8,7,'A','Executable selector removed')
    txt(ax,532,9,'EXP2-GOLD-049  |  Partial',8.5,AMBER,ha='right')
    txt(ax,8,31,'Selected source expression',8.5,GRAY)
    txt(ax,326,31,'Captured native expression',8.5,GRAY)
    box(ax,8,49,276,39,BLUE_FILL,LINE,.7)
    box(ax,326,49,206,39,AMBER_FILL,AMBER,.7)
    txt(ax,18,63,'runs_df["actual_output"].sum()',9.4,INK,mono=True)
    txt(ax,337,63,'runs_df[].sum()',9.4,AMBER,mono=True)
    arrow(ax,[(284,68),(326,68)],AMBER)
    txt(ax,8,103,'Blanking string tokens removes the column key.',9,INK)
    txt(ax,8,118,'The selected sum is also an intermediate value in the scrap-rate calculation.',9,GRAY)
    line(ax,8,144,532,144)
    # B: same source input -> same selected output despite four named references.
    heading(ax,8,159,'B','Requested output is not bound to expression selection')
    txt(ax,8,184,'Four reference identities share one source region',9,GRAY)
    box(ax,8,204,150,103,BLUE_FILL,NAVY,.7)
    for i,(name,suffix) in enumerate([('Availability','041'),('Performance','042'),('Quality','043'),('OEE','044')]):
        y=214+i*23
        txt(ax,18,y,name,9,NAVY)
        txt(ax,148,y,suffix,8.3,GRAY,ha='right',mono=True)
    arrow(ax,[(158,255),(186,255)])
    box(ax,186,222,173,65,WHITE,NAVY,.8)
    txt(ax,272.5,233,'Same captured expression',8.8,GRAY,ha='center')
    txt(ax,272.5,257,'runtime / planned',10.1,NAVY,ha='center',mono=True)
    arrow(ax,[(359,255),(386,255)],AMBER)
    txt(ax,397,219,'Frozen verdicts',8.6,GRAY)
    txt(ax,397,242,'041: Partial',9.4,AMBER,'bold')
    txt(ax,397,264,'042-044: Incorrect',9.4,AMBER,'bold')
    txt(ax,8,319,'The availability expression is returned for availability, performance, quality and OEE.',9,INK)
    line(ax,8,343,532,343)
    # C: source text with guard shown independently from selected later return.
    heading(ax,8,358,'C','Preceding control branch omitted')
    txt(ax,532,360,'EXP2-GOLD-061  |  Partial',8.5,AMBER,ha='right')
    box(ax,8,383,358,80,WHITE,NAVY,.7)
    box(ax,9,384,356,38,AMBER_FILL,AMBER_FILL,0)
    txt(ax,18,390,'if self.total_items == 0:',8.8,INK,mono=True)
    txt(ax,18,406,'    return 0',8.8,INK,mono=True)
    txt(ax,18,432,'return round(self.counted_items /',8.8,INK,mono=True)
    txt(ax,18,447,'             self.total_items * 100, 1)',8.8,INK,mono=True)
    arrow(ax,[(366,403),(386,403)],AMBER)
    txt(ax,396,392,'Guard + fallback',9,AMBER,'bold')
    txt(ax,396,406,'omitted',9,AMBER)
    arrow(ax,[(366,444),(386,444)],NAVY)
    txt(ax,396,432,'Later expression',9,NAVY,'bold')
    txt(ax,396,446,'selected',9,NAVY)
    save(fig,'fig04_reconstruction_mechanisms')

if __name__=='__main__':
    architecture(); channels(); geometry(); mechanisms()
    print('Generated four PDF, SVG and 200 dpi PNG figure sets.')
